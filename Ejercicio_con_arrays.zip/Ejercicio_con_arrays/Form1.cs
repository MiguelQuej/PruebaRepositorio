﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InputKey;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ejercicio_con_arrays
{
    public partial class Frn1 : Form
    {
        int posicion;
        string[] nombre;
        string[] salario;
        double bono;
        public Frn1()
        {
            InitializeComponent();
        }

        private void Rellenar_Click(object sender, EventArgs e)
        {
            posicion = int.Parse(txt3.Text);
            nombre = new string[posicion];
            salario = new string[posicion];

            for (int i = 0; i < posicion; i++)
            {
                nombre[i] = InputDialog.mostrar("ingrese el nombre: ");
            }
            nombre[0] = txt1.Text;
            for (int i = 0; i < posicion; i++)
            {
                MessageBox.Show("El nombre es: " + nombre[i]);
            }
            for (int i = 0; i < posicion; i++)
            {
                salario[i] = InputDialog.mostrar("Ingrese el salario: ");
            }
            salario[0] = txt2.Text;
            for (int i = 0; i < posicion; i++)
            {
                if (Convert.ToDouble(salario[i]) > 3000)
                {
                    double bono = (Convert.ToDouble(salario[i]) + ((Convert.ToDouble(salario[i]) * 0.1)));
                    MessageBox.Show("El salario con el añadido de un bono es de:" + bono);
                }
                else
                {
                    MessageBox.Show("El salario es de: " + salario[i]);
                }
            }

                }
        }
    }
