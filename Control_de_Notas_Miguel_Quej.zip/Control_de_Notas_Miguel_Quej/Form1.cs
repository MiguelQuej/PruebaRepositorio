﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Control_de_Notas_Miguel_Quej
{
    public partial class frnLogin : Form
    {
        public frnLogin()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //try-catch
            try
            {
                //byte texto = Convert.ToByte(txtIngreso.Text);
                //lblMostrar.Text = texto.ToString();
                //string usuario = txtIngreso.Text;

                if (txtUsuario.Text == "Miguel" && txtContraseña.Text == "Miguel12$")
                {
                    this.Hide();
                    ControlNotas frm = new ControlNotas();
                    frm.Show();

                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrecto");
                }
            }

            catch (OverflowException y)
            {
                MessageBox.Show("El error es:" + y);
            }
            catch (FormatException v)
            {
                MessageBox.Show("El error es:" + v);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
