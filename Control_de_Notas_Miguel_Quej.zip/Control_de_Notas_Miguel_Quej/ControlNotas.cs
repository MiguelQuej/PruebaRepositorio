﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Control_de_Notas_Miguel_Quej
{
    public partial class ControlNotas : Form
    {
        public ControlNotas()
        {
            InitializeComponent();
        }

        private void btnPromediar_Click(object sender, EventArgs e)
        {
            double Nota1 = double.Parse(txtNota1.Text);
            double Nota2 = double.Parse(txtNota2.Text);
            double Nota3 = double.Parse(txtNota3.Text);
            double Nota4 = double.Parse(txtNota4.Text);

            double promedio = ((Nota1 + Nota2 + Nota3 + Nota4) / 4);

            if (Nota1 > 100) 
            { MessageBox.Show("La Nota 1 no puede ser mayor a 100, revise sus notas");
                if (Nota2 > 100)
                {
                    MessageBox.Show("La Nota 2 no puede ser mayor a 100, revise sus notas");
                    if (Nota3 > 100) 
                    {
                        MessageBox.Show("La nota 3 no puede ser mayor a 100, revise sus notas");
                        if (Nota4 > 100) 
                        {
                            MessageBox.Show("La nota 4 no puede ser mayor a 100, revise sus notas");
                        }
                    }
                }
            }
            else
            {
                lblPromedio.Text = promedio.ToString();

                if (promedio >= 60) 
                {
                    lblMensaje.Text = "Felicidades, usted ha aprobado";
                }
                else
                {
                    lblMensaje.Text = "Lamentablemente usted ha reprobado";

                }
            }
        }

        private void ControlNotas_Load(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
